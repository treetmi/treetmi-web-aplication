"use client"

import React, { useEffect, useState } from "react"
import Link from "next/link"
import { PUBLIC_API } from "@/lib/api"

export function Footer() {
  const currentYear = new Date().getFullYear()
  const [permits, setPermits] = useState({ ahu: "", pse: "", nib: "" })
  const [logoText, setLogoText] = useState("")
  const [logoUrl, setLogoUrl] = useState("")
  const [companyName, setCompanyName] = useState("")

  useEffect(() => {
    if (typeof window !== "undefined") {
      const cachedText = localStorage.getItem("treetmi_logo_text")
      const cachedUrl = localStorage.getItem("treetmi_logo_url")
      if (cachedText) setLogoText(cachedText)
      if (cachedUrl) setLogoUrl(cachedUrl)
    }

    fetch(PUBLIC_API.publicSettings)
      .then(r => r.json())
      .then(json => {
        if (json.success && json.data) {
          setPermits({
            ahu: json.data.ahuNumber || "",
            pse: json.data.pseNumber || "",
            nib: json.data.nibNumber || ""
          })
          setCompanyName(json.data.companyName || "")
        }
      })
      .catch(() => {})
  }, [])

  const hasPermits = permits.ahu || permits.pse || permits.nib

  return (
    <footer className="py-10 border-t border-[#EAE9E4] bg-white dark:bg-[#0A0A0A] dark:border-[#262626] z-10 relative">
      <div className="container mx-auto px-4 flex flex-col items-center gap-6 text-center max-w-[1360px]">
        
        {/* Logo and Nav Links */}
        <div className="w-full flex flex-col md:flex-row justify-between items-center gap-6 pb-6 border-b border-slate-100 dark:border-zinc-900/60">
          <Link href="/" className="flex items-center">
            {logoUrl ? (
              <img 
                src={logoUrl} 
                alt={logoText || "Logo"} 
                className="h-8 md:h-10 w-auto object-contain rounded-lg transition-all"
              />
            ) : (
              <span className="text-lg font-black italic uppercase tracking-tighter bg-[#FFD551] text-black px-2 py-0.5 animate-in fade-in duration-300">
                {logoText || "treetmi"}
              </span>
            )}
          </Link>
          <div className="flex gap-4 md:gap-6 text-xs font-semibold text-muted-foreground dark:text-[#A09E96] flex-wrap justify-center">
            <Link href="/about" className="hover:text-[#FFD551] transition-colors">Tentang Kami</Link>
            <Link href="/terms" className="hover:text-[#FFD551] transition-colors">Syarat & Ketentuan</Link>
            <Link href="/privacy" className="hover:text-[#FFD551] transition-colors">Kebijakan Privasi</Link>
            <Link href="/faq" className="hover:text-[#FFD551] transition-colors">FAQ</Link>
          </div>
        </div>

        {/* Dynamic Permits & Copyright Area */}
        <div className="space-y-2 text-slate-400 dark:text-[#A09E96] text-[10px] font-semibold w-full">
          {hasPermits && (
            <div className="flex flex-wrap justify-center gap-2 md:gap-4 text-slate-500 dark:text-zinc-500 text-[11px] uppercase tracking-wider font-bold mb-1">
              {permits.ahu && (
                <span>⚖️ AHU: <strong className="text-slate-600 dark:text-zinc-400">{permits.ahu}</strong></span>
              )}
              {permits.ahu && (permits.pse || permits.nib) && <span className="hidden md:inline text-slate-300 dark:text-zinc-800">|</span>}
              {permits.nib && (
                <span>🏢 NIB: <strong className="text-slate-600 dark:text-zinc-400">{permits.nib}</strong></span>
              )}
              {permits.nib && permits.pse && <span className="hidden md:inline text-slate-300 dark:text-zinc-800">|</span>}
              {permits.pse && (
                <span>💻 PSE: <strong className="text-slate-600 dark:text-zinc-400">{permits.pse}</strong></span>
              )}
            </div>
          )}
          
          <p className="text-slate-400 dark:text-[#A09E96]">
            © {currentYear} {companyName || "Treetmi.id"}. All rights reserved.
          </p>
          <p className="text-slate-300 dark:text-zinc-600 text-[9px] font-bold italic">
            Powered by Treetmi.id — Platform Dukungan Kreator Terbesar di Indonesia
          </p>
        </div>

      </div>
    </footer>
  )
}