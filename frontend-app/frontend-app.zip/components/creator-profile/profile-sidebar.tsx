"use client"

import React from "react"
import { 
  ShieldCheck, Share2, Bell, TrendingUp, Calendar, Clock, Star, Flame, Trophy, Globe
} from "lucide-react"
import { useCurrency } from "@/components/currency-provider"
import { useLanguage } from "@/components/language-provider"

// SVG custom icons for socials to match original creator-profile-view
const InstagramIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
  </svg>
)

const YoutubeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M2.5 17a24.12 24.12 0 0 1 0-10 2 2 0 0 1 1.4-1.4 49.56 49.56 0 0 1 16.2 0A2 2 0 0 1 21.5 7a24.12 24.12 0 0 1 0 10 2 2 0 0 1-1.4 1.4 49.55 49.55 0 0 1-16.2 0A2 2 0 0 1 2.5 17z" />
    <polygon points="10 15 15 12 10 9" />
  </svg>
)

const DiscordIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M18 8a3 3 0 0 0-3-3H9a3 3 0 0 0-3 3v8a3 3 0 0 0 3 3h6a3 3 0 0 0 3-3V8Z" />
    <circle cx="10" cy="12" r="1" />
    <circle cx="14" cy="12" r="1" />
  </svg>
)

const FacebookIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
  </svg>
)

const TwitchIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M21 2H3v16h5v4l4-4h5l4-4V2zm-10 9H9V6h2v5zm4 0h-2V6h2v5z" />
  </svg>
)

const TiktokIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
  </svg>
)

const TrustBadge = ({ count = 0, dbBadge }: { count: number, dbBadge?: any }) => {
  if (dbBadge) {
    return (
      <div className="mt-1.5 flex items-center justify-center select-none">
        <img 
          src={dbBadge.badge_url}
          alt={dbBadge.name}
          className="h-7 w-auto object-contain max-w-[130px] select-none"
          title={`${dbBadge.name} (${count} Pendukung)`}
          onError={(e) => {
            e.currentTarget.style.display = "none"
          }}
        />
      </div>
    )
  }

  return null
}

interface ProfileSidebarProps {
  creatorDbData: any
  displayUsername: string
  config: any
  dbSchedules: any[]
  dbScheduleTitle: string
  onBellClick: () => void
  onShareClick: () => void
}

export function ProfileSidebar({
  creatorDbData,
  displayUsername,
  config,
  dbSchedules,
  dbScheduleTitle,
  onBellClick,
  onShareClick
}: ProfileSidebarProps) {
  const { currency, convertFromIdr, format: formatCurrency } = useCurrency()
  const { lang, t } = useLanguage()

  const accumulated = creatorDbData
    ? (creatorDbData.target_collected !== undefined ? Number(creatorDbData.target_collected) : parseFloat(creatorDbData.balance))
    : 4500000
  const targetGoal = creatorDbData?.target_amount ? parseFloat(creatorDbData.target_amount) : 10000000
  const percent = targetGoal > 0 ? Math.min(100, Math.round((accumulated / targetGoal) * 100)) : 0
  const targetTitle = creatorDbData?.target_title || config.targetTitle

  const getBannerGradient = () => {
    const roleTitle = creatorDbData?.role_title || config.role || ""
    const norm = roleTitle.toLowerCase()
    
    if (norm.includes("dev") || norm.includes("code") || norm.includes("programmer") || norm.includes("software") || norm.includes("tech") || norm.includes("engineer")) {
      return "from-slate-700 to-slate-900 dark:from-zinc-800 dark:to-zinc-950"
    }
    if (norm.includes("design") || norm.includes("art") || norm.includes("artist") || norm.includes("creative") || norm.includes("sketch") || norm.includes("ui") || norm.includes("ux")) {
      return "from-violet-600 to-fuchsia-500 dark:from-purple-900 dark:to-fuchsia-800"
    }
    if (norm.includes("write") || norm.includes("edit") || norm.includes("story") || norm.includes("author") || norm.includes("poet") || norm.includes("jurnal")) {
      return "from-teal-500 to-cyan-500 dark:from-teal-800 dark:to-cyan-900"
    }
    // Default (Gamer / Other)
    return "from-amber-400 to-[#FFD551]/60 dark:from-[#FFD551]/40 dark:to-[#FFD551]/10"
  }

  // Helper to build external redirect URL — opens in new tab so profile page stays open
  const externalLink = (url: string) => `/leave?url=${encodeURIComponent(url)}`

  return (
    <div className="bg-[#FAF8F2] dark:bg-[#181818] border-2 border-zinc-950 dark:border-zinc-800 rounded-2xl p-6 shadow-[4px_4px_0px_#1a1a1a] dark:shadow-[4px_4px_0px_#000000] space-y-6 relative overflow-hidden">
      
      {/* Dynamic Header Cover Image / Gradient */}
      {creatorDbData?.banner_url ? (
        <div 
          className="absolute top-0 left-0 right-0 h-36 z-0 bg-cover bg-center border-b border-zinc-950/40 dark:border-zinc-800/40" 
          style={{ backgroundImage: `url(${creatorDbData.banner_url})` }}
        />
      ) : (
        <div className={`absolute top-0 left-0 right-0 h-36 bg-gradient-to-r ${getBannerGradient()} z-0 border-b border-zinc-950/40 dark:border-zinc-800/40`} />
      )}

      {/* Floating Controls Overlay inside Banner */}
      <div className="absolute top-4 right-4 flex items-center gap-2 z-20">
        {/* Share */}
        <button 
          onClick={onShareClick}
          className="flex items-center justify-center h-9 w-9 rounded-xl bg-white border border-[#E5E3DD] shadow-sm hover:bg-[#F8F7F3] active:scale-[0.93] transition-all dark:bg-[#1D1D1D] dark:border-[#2E2E2E] dark:hover:bg-[#262626]"
          aria-label="Share Profile"
        >
          <Share2 className="h-4 w-4 text-[#706E68] dark:text-[#A09E96]" />
        </button>
        
        {/* Bell Notification */}
        <button 
          onClick={onBellClick}
          className="flex items-center justify-center h-9 w-9 rounded-xl bg-white border border-[#E5E3DD] shadow-sm hover:bg-[#F8F7F3] active:scale-[0.93] transition-all dark:bg-[#1D1D1D] dark:border-[#2E2E2E] dark:hover:bg-[#262626] relative"
          aria-label="Stream Alerts"
        >
          <Bell className="h-4 w-4 text-[#706E68] dark:text-[#A09E96]" />
          <span className="absolute top-0 right-0 h-2.5 w-2.5 bg-[#FFD551] border-2 border-white rounded-full dark:border-[#141414]" />
        </button>
      </div>

      {/* Live indicator bubble floating top left inside Banner */}
      <div className="absolute top-4 left-4 flex items-center gap-1.5 bg-white dark:bg-[#1D1D1D] px-3 py-1.5 rounded-full border border-slate-200 dark:border-zinc-800 shadow-sm z-20">
        {creatorDbData && !creatorDbData.is_live ? (
          <>
            <div className="h-2 w-2 rounded-full bg-zinc-400 animate-pulse" />
            <span className="text-[9px] font-black tracking-widest uppercase italic text-zinc-400">OFFLINE</span>
          </>
        ) : (
          <>
            <div className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-555"></span>
            </div>
            <span className="text-[9px] font-black tracking-widest uppercase italic text-red-650 dark:text-red-400">LIVE</span>
          </>
        )}
      </div>
      
      {/* Profile Header Block */}
      <div className="relative pt-20 flex flex-col items-center text-center z-10 space-y-4">

        {/* Avatar Box */}
        <div className="relative group mt-2">
          {/* Avatar Rounded Square */}
          <div className="relative w-24 h-24 rounded-xl bg-white border-2 border-zinc-950 dark:border-zinc-800 overflow-hidden flex items-center justify-center text-3xl font-black italic shadow-[3px_3px_0px_#1a1a1a] dark:shadow-[3px_3px_0px_#000000] dark:bg-[#1C1C1C]">
            {creatorDbData?.avatar_url ? (
              <img src={creatorDbData.avatar_url} alt={displayUsername} className="w-full h-full object-cover" />
            ) : (
              config.avatarChar
            )}
          </div>
        </div>

        {/* Name and verified badge */}
        <div className="space-y-1.5 flex flex-col items-center">
          <h1 className="text-2xl font-black tracking-tight flex items-center gap-1.5 justify-center leading-none text-slate-800 dark:text-[#EAE9E4]">
            @{displayUsername}
            {creatorDbData?.is_verified && (
              <img src="/verified.svg" alt="Verified" className="w-[24px] h-[24px] shrink-0" />
            )}
          </h1>
          <p className="text-[10px] font-extrabold text-slate-400 dark:text-zinc-500 uppercase tracking-widest italic">
            {creatorDbData?.role_title || config.role}
          </p>
          <TrustBadge count={creatorDbData?.unique_supporters || 0} dbBadge={creatorDbData?.trust_badge} />
        </div>

        {/* Bio description */}
        <p className="text-xs font-semibold text-slate-500 dark:text-zinc-400 max-w-[280px] leading-relaxed">
          {creatorDbData?.bio || config.bio}
        </p>

        {/* Social Icons row — uses /leave redirect for external links */}
        <div className="flex justify-center flex-wrap gap-2.5 pt-1.5">
          {creatorDbData?.instagram_url && (
            <a href={externalLink(creatorDbData.instagram_url)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-8 w-8 rounded-lg bg-white border border-[#E5E3DD] shadow-sm hover:border-[#FFD551] hover:text-pink-500 active:scale-[0.9] transition-all dark:bg-zinc-900 dark:border-zinc-800">
              <InstagramIcon className="h-4 w-4 text-slate-500 dark:text-[#A09E96]" />
            </a>
          )}
          
          {creatorDbData?.youtube_url && (
            <a href={externalLink(creatorDbData.youtube_url)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-8 w-8 rounded-lg bg-white border border-[#E5E3DD] shadow-sm hover:border-[#FFD551] hover:text-red-500 active:scale-[0.9] transition-all dark:bg-zinc-900 dark:border-zinc-800">
              <YoutubeIcon className="h-4 w-4 text-slate-500 dark:text-[#A09E96]" />
            </a>
          )}

          {creatorDbData?.discord_url && (
            <a href={externalLink(creatorDbData.discord_url)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-8 w-8 rounded-lg bg-white border border-[#E5E3DD] shadow-sm hover:border-[#FFD551] hover:text-[#5865F2] active:scale-[0.9] transition-all dark:bg-zinc-900 dark:border-zinc-800">
              <DiscordIcon className="h-4 w-4 text-slate-500 dark:text-[#A09E96]" />
            </a>
          )}

          {creatorDbData?.facebook_url && (
            <a href={externalLink(creatorDbData.facebook_url)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-8 w-8 rounded-lg bg-white border border-[#E5E3DD] shadow-sm hover:border-[#FFD551] hover:text-[#1877F2] active:scale-[0.9] transition-all dark:bg-zinc-900 dark:border-zinc-800">
              <FacebookIcon className="h-4 w-4 text-slate-500 dark:text-[#A09E96]" />
            </a>
          )}

          {creatorDbData?.twitch_url && (
            <a href={externalLink(creatorDbData.twitch_url)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-8 w-8 rounded-lg bg-white border border-[#E5E3DD] shadow-sm hover:border-[#FFD551] hover:text-[#9146FF] active:scale-[0.9] transition-all dark:bg-zinc-900 dark:border-zinc-800">
              <TwitchIcon className="h-4 w-4 text-slate-500 dark:text-[#A09E96]" />
            </a>
          )}

          {creatorDbData?.tiktok_url && (
            <a href={externalLink(creatorDbData.tiktok_url)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-8 w-8 rounded-lg bg-white border border-[#E5E3DD] shadow-sm hover:border-[#FFD551] active:scale-[0.9] transition-all dark:bg-zinc-900 dark:border-zinc-800">
              <TiktokIcon className="h-4 w-4 text-slate-500 dark:text-[#A09E96]" />
            </a>
          )}

          {creatorDbData?.website_url && (
            <a href={externalLink(creatorDbData.website_url)} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center h-8 w-8 rounded-lg bg-white border border-[#E5E3DD] shadow-sm hover:border-[#FFD551] hover:text-emerald-500 active:scale-[0.9] transition-all dark:bg-zinc-900 dark:border-zinc-800">
              <Globe className="h-4 w-4 text-slate-500 dark:text-[#A09E96]" />
            </a>
          )}
        </div>
      </div>

      {/* Target Progress Bar Widget */}
      {creatorDbData?.show_target !== false && (
        <div className="p-4 bg-[#FAF6EE]/80 dark:bg-zinc-950/40 border border-zinc-950/60 dark:border-zinc-800/60 rounded-xl space-y-2.5 shadow-[3px_3px_0px_rgba(0,0,0,0.85)]">
          <div className="flex justify-between items-end">
            <div className="flex items-center gap-1.5">
              <TrendingUp className="h-4 w-4 text-black dark:text-white" />
              <span className="text-[10px] font-black uppercase italic tracking-widest text-slate-800 dark:text-[#EAE9E4]">{targetTitle}</span>
            </div>
            <span className="text-[10px] font-black italic text-red-650 dark:text-red-450">{percent}%</span>
          </div>
          
          {/* Progress bar container */}
          <div className="h-4 w-full bg-[#FAF9F6] rounded-lg overflow-hidden p-0.5 border border-zinc-950 dark:bg-[#1E1E1E]">
            <div className="h-full bg-[#FFD551] rounded-md border-r border-zinc-950 transition-all duration-500" style={{ width: `${percent}%` }} />
          </div>
          
          <div className="flex justify-between text-[9px] font-extrabold text-slate-400 uppercase italic dark:text-[#A09E96] leading-none">
            <span>{formatCurrency(accumulated)}</span>
            <span>{t.publicProfile?.target || "Target"}: {formatCurrency(targetGoal)}</span>
          </div>
        </div>
      )}

      {/* Jadwal Live Streaming Calendar Timeline */}
      {creatorDbData?.show_calendar === true && (
        <div className="p-4 bg-[#FAF6EE]/80 dark:bg-zinc-950/40 border border-zinc-950/60 dark:border-zinc-800/60 rounded-xl space-y-3.5 shadow-[3px_3px_0px_rgba(0,0,0,0.85)]">
          <div className="flex flex-col gap-0.5 pb-2 border-b border-zinc-950/60">
            <span className="text-[10px] font-black uppercase italic tracking-widest flex items-center gap-1.5 text-slate-800 dark:text-[#EAE9E4]">
              <Calendar className="h-4 w-4 text-[#FFD551] fill-current" /> {dbScheduleTitle}
            </span>
          </div>

          {dbSchedules.length > 0 ? (
            <div className="space-y-3 max-h-[220px] overflow-y-auto pr-1">
              {dbSchedules.map((event: any, idx: number) => {
                let formattedDate = ""
                try {
                  const d = new Date(event.date)
                  formattedDate = d.toLocaleDateString("id-ID", {
                    weekday: "short",
                    day: "numeric",
                    month: "short"
                  }) + " - " + d.toLocaleTimeString("id-ID", {
                    hour: "2-digit",
                    minute: "2-digit"
                  }) + " WIB"
                } catch (e) {
                  formattedDate = event.date
                }

                return (
                  <div 
                    key={event.id || idx}
                    className="p-2.5 bg-[#FAF9F5] border border-zinc-950/40 rounded-lg space-y-1.5 dark:bg-[#1E1E1E] transition-all hover:bg-slate-50 dark:hover:bg-zinc-800 shadow-[1.5px_1.5px_0px_rgba(0,0,0,0.85)]"
                  >
                    <div className="flex flex-col gap-1">
                      <div className="flex items-start gap-1.5 flex-wrap">
                        <span className="inline-block text-[8px] font-black uppercase italic bg-[#FFD551] text-black px-1.5 py-0.5 rounded border border-zinc-950 leading-none shadow-[1px_1px_0px_rgba(0,0,0,0.8)]">
                          {event.category}
                        </span>
                        <span className="text-[8.5px] font-extrabold text-red-500 italic flex items-center gap-1 dark:text-red-450">
                          <Clock className="h-3 w-3" /> {formattedDate}
                        </span>
                      </div>
                      <span className="text-[10px] font-black uppercase italic leading-tight text-slate-850 dark:text-[#EAE9E4]">
                        {event.title}
                      </span>
                    </div>
                  </div>
                )
              })}
            </div>
          ) : (
            <div className="py-4 text-center space-y-1">
              <span className="text-xl block">📅</span>
              <p className="text-[10px] font-extrabold italic text-slate-400 dark:text-zinc-500">
                Belum ada jadwal stream.
              </p>
            </div>
          )}
        </div>
      )}

    </div>
  )
}